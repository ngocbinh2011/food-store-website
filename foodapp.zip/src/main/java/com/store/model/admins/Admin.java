package com.store.model.admins;

import com.store.model.customers.Customer;

public class Admin extends Customer {


}
